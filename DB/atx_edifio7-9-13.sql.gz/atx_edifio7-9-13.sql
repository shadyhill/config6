# ************************************************************
# Sequel Pro SQL dump
# Version 4063
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: shserver.local (MySQL 5.5.15)
# Database: atx_edifio
# Generation Time: 2013-07-10 01:12:02 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table accounts
# ------------------------------------------------------------

DROP TABLE IF EXISTS `accounts`;

CREATE TABLE `accounts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(32) DEFAULT NULL,
  `username` varchar(150) DEFAULT NULL,
  `salt` varchar(12) DEFAULT NULL,
  `password` varchar(40) DEFAULT NULL,
  `s3bucket` varchar(4) DEFAULT NULL,
  `status` int(2) DEFAULT NULL,
  `status_txt` varchar(20) DEFAULT NULL,
  `pass_reset` varchar(40) DEFAULT NULL,
  `pass_reset_exp` date DEFAULT NULL,
  `token` varchar(200) DEFAULT NULL,
  `confirmation` varchar(200) DEFAULT NULL,
  `confirmed` int(2) DEFAULT NULL,
  `stripe_customer` varchar(100) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mm_id` (`uuid`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table admin_logins
# ------------------------------------------------------------

DROP TABLE IF EXISTS `admin_logins`;

CREATE TABLE `admin_logins` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `manager_id` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `user` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `pass` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `active` int(11) DEFAULT NULL,
  `permission` int(2) DEFAULT NULL,
  `stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user` (`user`),
  UNIQUE KEY `manager_id` (`manager_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `admin_logins` WRITE;
/*!40000 ALTER TABLE `admin_logins` DISABLE KEYS */;

INSERT INTO `admin_logins` (`id`, `manager_id`, `user`, `pass`, `active`, `permission`, `stamp`)
VALUES
	(8,'shadyhill','shadyhill','3d4f29891a489c9eff2a4407253d44dd',1,1,'2012-05-29 08:29:17');

/*!40000 ALTER TABLE `admin_logins` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table form_fields
# ------------------------------------------------------------

DROP TABLE IF EXISTS `form_fields`;

CREATE TABLE `form_fields` (
  `form_id` int(11) DEFAULT NULL,
  `f_order` int(11) DEFAULT NULL,
  `type` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `label` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `name_id` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `placeholder` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `width` int(4) DEFAULT NULL,
  `class_override` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `style_override` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `dd_displays` text CHARACTER SET utf8 COMMENT 'select menu displays',
  `dd_values` text CHARACTER SET utf8 COMMENT 'select menu values',
  `has_hint` int(2) DEFAULT NULL,
  `hint_txt` text CHARACTER SET utf8,
  `has_error` int(2) DEFAULT NULL,
  `error_txt` text CHARACTER SET utf8,
  `stamp` date DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `form_fields` WRITE;
/*!40000 ALTER TABLE `form_fields` DISABLE KEYS */;

INSERT INTO `form_fields` (`form_id`, `f_order`, `type`, `label`, `name_id`, `placeholder`, `width`, `class_override`, `style_override`, `dd_displays`, `dd_values`, `has_hint`, `hint_txt`, `has_error`, `error_txt`, `stamp`, `updated`)
VALUES
	(1,1,'text','USERNAME','f_user','Manager Login',300,'',NULL,NULL,NULL,0,NULL,0,NULL,'2012-03-27','2012-03-27 20:46:56'),
	(1,2,'password','PASSWORD','f_pass','Password',300,NULL,NULL,NULL,NULL,0,NULL,0,NULL,'2012-03-27','2012-03-27 20:46:58'),
	(2,2,'text','Page URL','page_url','url/with/trailing/slash/',300,'span4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-07-03 23:13:42'),
	(2,1,'text','Page Name','page_name','Name of Page',300,'span4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-07-03 23:13:41'),
	(2,8,'checkbox','','is_index',NULL,300,NULL,NULL,'Is Index','',NULL,NULL,NULL,NULL,NULL,'2013-07-03 23:06:57'),
	(2,9,'checkbox','','override_path',NULL,300,'span4',NULL,'Override Path?','',NULL,NULL,NULL,NULL,NULL,'2013-07-03 23:13:40'),
	(2,3,'text','Include File','include_file','some/path/file.php',300,'span4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-07-04 08:42:23'),
	(2,5,'text','Page Title (Meta)','meta_title','Page Title',300,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-07-03 23:06:51'),
	(2,6,'textarea','Meta Description','meta_description','Meta description text for search engines.',300,'span5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-07-04 08:46:19'),
	(2,7,'text','Meta Keywords','meta_keywords',NULL,300,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-07-03 23:06:54'),
	(3,1,'text','Page Name','page_name','Name of Page',300,'span4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-07-03 23:13:41'),
	(3,2,'text','Page URL','page_url','url/with/trailing/slash/',300,'span4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-07-03 23:13:42'),
	(3,3,'text','Include File','include_file','some/path/file.php',300,'span4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-07-04 08:42:23'),
	(3,5,'text','Page Title (Meta)','meta_title','Page Title',300,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-07-03 23:06:51'),
	(3,6,'textarea','Meta Description','meta_description','Meta description text for search engines.',300,'span5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-07-04 08:46:19'),
	(3,7,'text','Meta Keywords','meta_keywords',NULL,300,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-07-03 23:06:54'),
	(3,8,'checkbox','','is_index',NULL,300,NULL,NULL,'Is Index','',NULL,NULL,NULL,NULL,NULL,'2013-07-03 23:06:57'),
	(3,9,'checkbox','','override_path',NULL,300,'span4',NULL,'Override Path?','',NULL,NULL,NULL,NULL,NULL,'2013-07-03 23:13:40'),
	(3,10,'hidden',NULL,'page_id',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-07-04 15:03:58'),
	(4,1,'text','*Form Name','form_name','Name the form',NULL,'span4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-07-06 15:12:41'),
	(4,2,'text','*AJAX URL','ajax_action_url','manager/AJAX/obj/fx/',NULL,'span4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-07-07 14:16:09'),
	(4,9,'selectmenu','Form Type','form_type',NULL,NULL,'span2',NULL,'AJAX|DEFAULT (POST)','AJAX|DEFAULT (POST)',NULL,NULL,NULL,NULL,NULL,'2013-07-06 15:12:13'),
	(4,8,'text','Action','action',NULL,NULL,'span4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-07-06 15:12:11'),
	(4,5,'text','On Submit Function','onsubmit','submitAJAX',NULL,'span4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-07-06 15:13:15'),
	(4,10,'selectmenu','Method','method',NULL,NULL,'span2',NULL,'post|get','post|get',NULL,NULL,NULL,NULL,NULL,'2013-07-06 15:12:15'),
	(4,4,'text','Button Text','button_txt','Submit',NULL,'span4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-07-06 15:12:03'),
	(4,11,'selectmenu','Encoding','encoding',NULL,NULL,'span2',NULL,'None|Multipart','|multipart/form-data',NULL,NULL,NULL,NULL,NULL,'2013-07-06 15:12:17'),
	(4,6,'text','Preprocess Function','pre_process',NULL,NULL,'span4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-07-06 15:12:06'),
	(4,7,'text','Postprocess Function','post_process',NULL,NULL,'span4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-07-06 15:12:09'),
	(4,3,'text','*Class','form_class','form-horizontal',NULL,'span4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-07-06 15:14:12'),
	(5,1,'selectmenu','Type','type',NULL,NULL,'',NULL,'Text Box|Password|Textarea|Select Menu|Check Box|DB Select Menu','text|password|textarea|selectmenu|checkbox|dbselectmenu',NULL,NULL,NULL,NULL,NULL,'2013-07-08 23:54:57'),
	(5,2,'text','Label','label',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-07-08 23:52:41'),
	(5,3,'text','Name/ID','name_id',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-07-08 23:52:55'),
	(5,4,'text','Placeholder','placeholder',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-07-08 23:53:07'),
	(5,5,'text','Class Override','class_override','span4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-07-08 23:53:27'),
	(5,6,'text','Style Override','style_override',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-07-08 23:53:46'),
	(5,7,'textarea','Displays','dd_displays',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-07-08 23:54:16'),
	(5,8,'textarea','Values','dd_values',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-07-08 23:54:34'),
	(5,9,'hidden','','form_id',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-07-08 23:55:26'),
	(9,NULL,'text','My INput','my_input','place please',NULL,'span4','','','',NULL,NULL,NULL,NULL,NULL,'2013-07-09 00:01:10');

/*!40000 ALTER TABLE `form_fields` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table forms
# ------------------------------------------------------------

DROP TABLE IF EXISTS `forms`;

CREATE TABLE `forms` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `form_name` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `ajax_url` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `form_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `action` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `method` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `onsubmit` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `pre_process` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `post_process` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `form_class` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `button_txt` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `encoding` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `has_error_field` int(2) DEFAULT NULL,
  `stamp` date DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `forms` WRITE;
/*!40000 ALTER TABLE `forms` DISABLE KEYS */;

INSERT INTO `forms` (`id`, `form_name`, `ajax_url`, `form_type`, `action`, `method`, `onsubmit`, `pre_process`, `post_process`, `form_class`, `button_txt`, `encoding`, `has_error_field`, `stamp`, `updated`)
VALUES
	(1,'manager-login','manager/AJAX/manager/login/','AJAX','#manager-login','post','validateMLogin',NULL,NULL,'managerForm','LOGIN',NULL,1,'2012-03-27','2013-07-08 21:18:29'),
	(2,'m-settings-page-create','manager/AJAX/pages/create/','AJAX','#create-m-settings-page','post','submitAJAX',NULL,NULL,'form-horizontal','CREATE PAGE',NULL,1,NULL,'2013-07-03 22:46:50'),
	(3,'m-settings-page-edit','manager/AJAX/pages/edit/','AJAX','#create-m-settings-edit','post','submitAJAX',NULL,NULL,'form-horizontal','EDIT PAGE',NULL,1,NULL,'2013-07-04 14:56:10'),
	(4,'m-new-form','manager/AJAX/forms/create/','AJAX','#create-m-form','post','submitAJAX',NULL,NULL,'form-horizontal','CREATE FORM',NULL,1,NULL,'2013-07-06 14:58:30'),
	(5,'m-form-add-field','manager/AJAX/forms/addField/','AJAX','#m-form-add-field','post','submitAJAX',NULL,NULL,'form-horizontal','Add Field','',NULL,NULL,'2013-07-08 23:48:31'),
	(9,'Test Form','manager/AJAX/forms/test/','AJAX','','post','submitAJAX',NULL,NULL,'form-horizontal','Make a Test Form','',NULL,NULL,'2013-07-08 23:57:18');

/*!40000 ALTER TABLE `forms` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table manager_logins
# ------------------------------------------------------------

DROP TABLE IF EXISTS `manager_logins`;

CREATE TABLE `manager_logins` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `manager_id` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `user` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `pass` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `active` int(11) DEFAULT NULL,
  `permission` int(2) DEFAULT NULL,
  `stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user` (`user`),
  UNIQUE KEY `manager_id` (`manager_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `manager_logins` WRITE;
/*!40000 ALTER TABLE `manager_logins` DISABLE KEYS */;

INSERT INTO `manager_logins` (`id`, `manager_id`, `user`, `pass`, `active`, `permission`, `stamp`)
VALUES
	(8,'shadyhill','shadyhill','9206ce98bef7160c4a5479032fac31df',1,1,'2012-06-15 13:46:55');

/*!40000 ALTER TABLE `manager_logins` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table page_css
# ------------------------------------------------------------

DROP TABLE IF EXISTS `page_css`;

CREATE TABLE `page_css` (
  `page_url` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `css_file` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `css_order` int(3) DEFAULT NULL,
  `active` int(2) DEFAULT NULL,
  `stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY `page_url` (`page_url`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table page_data
# ------------------------------------------------------------

DROP TABLE IF EXISTS `page_data`;

CREATE TABLE `page_data` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `page_name` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `page_url` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `include_file` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `is_index` int(2) NOT NULL DEFAULT '0',
  `type` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_description` varchar(255) CHARACTER SET utf8 DEFAULT '',
  `meta_keywords` varchar(255) CHARACTER SET utf8 DEFAULT '',
  `meta_title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `active` int(2) NOT NULL DEFAULT '1',
  `stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `page_url` (`page_url`),
  KEY `page_url_2` (`page_url`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `page_data` WRITE;
/*!40000 ALTER TABLE `page_data` DISABLE KEYS */;

INSERT INTO `page_data` (`id`, `page_name`, `page_url`, `include_file`, `is_index`, `type`, `template`, `meta_description`, `meta_keywords`, `meta_title`, `active`, `stamp`)
VALUES
	(1,'Home Page','','PUBLIC/HOME/index.php',0,'PUBLIC',NULL,'','','Edifio -- Sheds with a purpose',1,'2012-02-14 18:21:09'),
	(2,'M: Login','manager/login/','MANAGER/login.php',0,'MANAGER',NULL,'','','Edifio -- Manager Login Page',1,'2012-03-22 11:49:41'),
	(5,'M: Settings: Pages: Create','manager/settings/pages/create/','MANAGER/SETTINGS/PAGES/create.php',0,'MANAGER',NULL,'','','',1,'2013-06-30 23:47:45'),
	(6,'M: Settings: Pages: List','manager/settings/pages/list/','MANAGER/SETTINGS/PAGES/list.php',0,'MANAGER',NULL,'','','',1,'2013-07-03 23:47:22'),
	(7,'M: Settings: Pages: View','manager/settings/pages/view/','MANAGER/SETTINGS/PAGES/view.php',0,'MANAGER',NULL,'','','',1,'2013-07-04 00:08:05'),
	(12,'M: Settings: Pages: Edit','manager/settings/pages/edit/','MANAGER/SETTINGS/PAGES/edit.php',0,'MANAGER',NULL,'','','',1,'2013-07-04 00:08:49'),
	(13,'M: Settings: JS: List','manager/settings/js/list/','MANAGER/SETTINGS/JS/list.php',0,'MANAGER',NULL,'','','',1,'2013-07-04 14:30:13'),
	(17,'M: Settings: Pages: Import','manager/settings/pages/import/','MANAGER/SETTINGS/PAGES/import.php',0,'MANAGER',NULL,'','',NULL,1,'2013-07-06 14:04:49'),
	(20,'Manager Home Login','manager/home/login/','MANAGER/HOME/login.php',0,'MANAGER',NULL,'','',NULL,1,'2013-07-06 14:43:52'),
	(23,'Status-codes 404','status-codes/404/','STATUS-CODES/404.php',0,'PUBLIC',NULL,'','',NULL,1,'2013-07-06 14:45:20'),
	(28,'Admin Login','admin/login/','ADMIN/login.php',0,'ADMIN',NULL,'','',NULL,1,'2013-07-06 14:49:37'),
	(33,'Manager Overview ','manager/overview/','MANAGER/OVERVIEW/index.php',1,'MANAGER',NULL,'','',NULL,1,'2013-07-06 14:53:43'),
	(34,'Manager Settings Pages ','manager/settings/pages/','MANAGER/SETTINGS/PAGES/index.php',1,'MANAGER',NULL,'','',NULL,1,'2013-07-06 14:54:02'),
	(35,'Manager Settings Forms Create','manager/settings/forms/create/','MANAGER/SETTINGS/FORMS/create.php',0,'MANAGER',NULL,'','',NULL,1,'2013-07-06 14:58:42'),
	(36,'Manager Settings Forms List','manager/settings/forms/list/','MANAGER/SETTINGS/FORMS/list.php',0,'MANAGER',NULL,'','',NULL,1,'2013-07-06 14:58:44'),
	(37,'Manager Settings Forms View','manager/settings/forms/view/','MANAGER/SETTINGS/FORMS/view.php',0,'MANAGER',NULL,'','',NULL,1,'2013-07-08 21:21:07'),
	(38,'Manager Settings Forms Add-field','manager/settings/forms/add-field/','MANAGER/SETTINGS/FORMS/add-field.php',0,'MANAGER',NULL,'','',NULL,1,'2013-07-08 23:48:48');

/*!40000 ALTER TABLE `page_data` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table page_js
# ------------------------------------------------------------

DROP TABLE IF EXISTS `page_js`;

CREATE TABLE `page_js` (
  `page_url` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `js_file` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `js_order` int(3) DEFAULT NULL,
  `active` int(2) DEFAULT NULL,
  `stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY `page_url` (`page_url`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `page_js` WRITE;
/*!40000 ALTER TABLE `page_js` DISABLE KEYS */;

INSERT INTO `page_js` (`page_url`, `js_file`, `js_order`, `active`, `stamp`)
VALUES
	('manager/login/','MANAGER/jMLogin.js',1,1,'2012-05-28 14:11:22');

/*!40000 ALTER TABLE `page_js` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
